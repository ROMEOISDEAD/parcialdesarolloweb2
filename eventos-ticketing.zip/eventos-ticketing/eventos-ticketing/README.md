# Sistema de Gestion de Eventos con Ticketing

Proyecto Final Integrador — Desarrollo de Aplicaciones Web II
Stack: Node.js + Express + React. ORM/persistencia con SQLite integrado (`node:sqlite`).

## Requisitos

- Node.js **22 o superior** (usa el modulo integrado `node:sqlite`, sin dependencias nativas).

Verifica tu version:

```bash
node --version
```

## Instalacion y ejecucion (3 comandos)

```bash
npm install        # instala dependencias (no compila nada)
npm run seed       # crea la base de datos y datos de prueba
npm start          # arranca el servidor
```

Luego abre **http://localhost:3000** en el navegador.

> Atajo: `npm run setup` ejecuta seed + start en un solo comando.

## Credenciales de prueba

| Rol     | Email                 | Password    |
|---------|-----------------------|-------------|
| Admin   | admin@eventos.com     | admin123    |
| Cliente | cliente@eventos.com   | cliente123  |

## Funcionalidades

- **Gestion de eventos (CRUD)** — solo admin puede crear/editar/eliminar.
- **Compra de tickets con reserva temporal** — reserva valida por 10 minutos antes de pagar.
- **API RESTful con autenticacion JWT** — tokens con expiracion configurable.
- **Roles y autorizacion** — `admin` y `cliente`.
- **Seguridad OWASP** — Helmet (headers), express-validator (validacion de entrada),
  bcrypt (hash de passwords), limite de payload.
- **Rate limiting** — 100 req/15min global, 5 intentos/15min en login (anti fuerza bruta).
- **Frontend React** — consume la API; sin paso de build (via CDN).

## Endpoints principales

| Metodo | Ruta                       | Acceso   | Descripcion                  |
|--------|----------------------------|----------|------------------------------|
| POST   | /api/auth/register         | Publico  | Registro de usuario          |
| POST   | /api/auth/login            | Publico  | Login (rate limited)         |
| GET    | /api/eventos               | Publico  | Lista eventos + disponibles  |
| GET    | /api/eventos/:id           | Publico  | Detalle de evento            |
| POST   | /api/eventos               | Admin    | Crear evento                 |
| PUT    | /api/eventos/:id           | Admin    | Actualizar evento            |
| DELETE | /api/eventos/:id           | Admin    | Eliminar evento              |
| POST   | /api/tickets/reservar      | Auth     | Reserva temporal (10 min)    |
| POST   | /api/tickets/comprar       | Auth     | Confirmar compra/pago        |
| GET    | /api/tickets/mis-tickets   | Auth     | Tickets del usuario          |
| GET    | /api/tickets               | Admin    | Todos los tickets            |
| GET    | /api/health                | Publico  | Estado del servidor          |

## Estructura del proyecto

```
src/
├── config/
│   └── database.js        # Conexion y esquema (FK entre tablas)
├── models/
│   ├── Usuario.js
│   ├── Evento.js          # incluye calculo de disponibilidad
│   └── Ticket.js          # JOINs evento/usuario
├── controllers/
│   ├── authController.js
│   ├── eventoController.js
│   └── ticketController.js
├── middleware/
│   ├── auth.js            # verificarToken + requiereRol
│   └── rateLimit.js
├── routes/
│   ├── authRoutes.js
│   ├── eventoRoutes.js
│   └── ticketRoutes.js
├── app.js                 # servidor Express + seguridad
└── seed.js                # datos de prueba
public/
└── index.html             # frontend React (CDN, sin build)
```

## Nota sobre la base de datos

El proyecto usa **SQLite mediante el modulo integrado `node:sqlite`** de Node 22,
lo que elimina la necesidad de instalar un servidor de base de datos o compilar
drivers nativos. Para usar PostgreSQL (como menciona el enunciado), se reemplazaria
la capa `src/config/database.js` y los modelos por Sequelize + `pg`; la arquitectura
MVC y los controladores permanecen iguales.
