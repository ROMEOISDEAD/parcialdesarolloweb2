const router = require('express').Router();
const { body } = require('express-validator');
const authController = require('../controllers/authController');
const { loginLimiter } = require('../middleware/rateLimit');

router.post('/register', [
  body('nombre').trim().notEmpty().withMessage('Nombre requerido'),
  body('email').isEmail().withMessage('Email invalido').normalizeEmail(),
  body('password').isLength({ min: 6 }).withMessage('Password minimo 6 caracteres'),
], authController.register);

router.post('/login', loginLimiter, [
  body('email').isEmail().withMessage('Email invalido').normalizeEmail(),
  body('password').notEmpty().withMessage('Password requerido'),
], authController.login);

module.exports = router;
