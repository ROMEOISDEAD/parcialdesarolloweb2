const router = require('express').Router();
const { body } = require('express-validator');
const ticketController = require('../controllers/ticketController');
const { verificarToken, requiereRol } = require('../middleware/auth');

router.post('/reservar', verificarToken, [
  body('evento_id').isInt().withMessage('evento_id requerido'),
], ticketController.reservar);

router.post('/comprar', verificarToken, ticketController.comprar);

router.get('/mis-tickets', verificarToken, ticketController.misTickets);

router.get('/', verificarToken, requiereRol('admin'), ticketController.listarTodos);

module.exports = router;
