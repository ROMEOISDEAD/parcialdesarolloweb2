const router = require('express').Router();
const { body } = require('express-validator');
const eventoController = require('../controllers/eventoController');
const { verificarToken, requiereRol } = require('../middleware/auth');

const validarEvento = [
  body('nombre').trim().notEmpty().withMessage('Nombre requerido'),
  body('fecha').isISO8601().withMessage('Fecha invalida'),
  body('lugar').trim().notEmpty().withMessage('Lugar requerido'),
  body('capacidad').isInt({ min: 1 }).withMessage('Capacidad debe ser >= 1'),
  body('precio').isFloat({ min: 0 }).withMessage('Precio invalido'),
];

// Publicas
router.get('/', eventoController.listar);
router.get('/:id', eventoController.obtener);

// Solo admin
router.post('/', verificarToken, requiereRol('admin'), validarEvento, eventoController.crear);
router.put('/:id', verificarToken, requiereRol('admin'), eventoController.actualizar);
router.delete('/:id', verificarToken, requiereRol('admin'), eventoController.eliminar);

module.exports = router;
