const { DatabaseSync } = require('node:sqlite');
const path = require('path');

// node:sqlite (integrado en Node 20.5+/22) — sin dependencias nativas ni servidor externo.
const db = new DatabaseSync(path.join(__dirname, '..', '..', 'database.sqlite'));

// Esquema con relaciones (FOREIGN KEY) — capa ORM/modelos del proyecto.
db.exec(`
  PRAGMA foreign_keys = ON;

  CREATE TABLE IF NOT EXISTS usuarios (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre        TEXT    NOT NULL,
    email         TEXT    NOT NULL UNIQUE,
    password_hash TEXT    NOT NULL,
    rol           TEXT    NOT NULL DEFAULT 'cliente' CHECK (rol IN ('admin','cliente')),
    createdAt     TEXT    DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS eventos (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre      TEXT    NOT NULL,
    descripcion TEXT,
    fecha       TEXT    NOT NULL,
    lugar       TEXT    NOT NULL,
    capacidad   INTEGER NOT NULL CHECK (capacidad >= 1),
    precio      REAL    NOT NULL DEFAULT 0,
    createdAt   TEXT    DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS tickets (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    codigo_unico   TEXT    NOT NULL UNIQUE,
    estado         TEXT    NOT NULL DEFAULT 'reservado' CHECK (estado IN ('reservado','pagado','expirado')),
    reserva_expira INTEGER,
    usuario_id     INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    evento_id      INTEGER NOT NULL REFERENCES eventos(id) ON DELETE CASCADE,
    createdAt      TEXT    DEFAULT (datetime('now'))
  );
`);

module.exports = db;
