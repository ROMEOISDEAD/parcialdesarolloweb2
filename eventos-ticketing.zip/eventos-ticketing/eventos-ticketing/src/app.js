require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const path = require('path');

require('./config/database'); // inicializa esquema
const { apiLimiter } = require('./middleware/rateLimit');

const authRoutes = require('./routes/authRoutes');
const eventoRoutes = require('./routes/eventoRoutes');
const ticketRoutes = require('./routes/ticketRoutes');

const app = express();

// --- Seguridad OWASP (Unidad 9) ---
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "https://unpkg.com", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      connectSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
    },
  },
}));
app.use(cors());
app.use(express.json({ limit: '10kb' }));      // limita payload (anti DoS)
app.use('/api/', apiLimiter);                  // rate limiting global

// --- Frontend estatico ---
app.use(express.static(path.join(__dirname, '..', 'public')));

// --- API ---
app.use('/api/auth', authRoutes);
app.use('/api/eventos', eventoRoutes);
app.use('/api/tickets', ticketRoutes);

app.get('/api/health', (req, res) => res.json({ status: 'ok', ts: new Date() }));

// Fallback SPA
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Ruta no encontrada' });
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`\n  Servidor en http://localhost:${PORT}`);
    console.log(`  Frontend:   http://localhost:${PORT}`);
    console.log(`  API health: http://localhost:${PORT}/api/health\n`);
  });
}

module.exports = app;
