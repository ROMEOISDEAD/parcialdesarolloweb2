const db = require('../config/database');

// Cuenta cupos ocupados: pagados + reservas vigentes (relacion eventos<->tickets)
function ocupados(eventoId) {
  return db.prepare(
    `SELECT COUNT(*) AS c FROM tickets
     WHERE evento_id = ?
       AND (estado = 'pagado' OR (estado = 'reservado' AND reserva_expira > ?))`
  ).get(eventoId, Date.now()).c;
}

const Evento = {
  ocupados,
  listar() {
    const eventos = db.prepare('SELECT * FROM eventos ORDER BY fecha ASC').all();
    return eventos.map((e) => ({ ...e, disponibles: e.capacidad - ocupados(e.id) }));
  },
  porId(id) {
    const e = db.prepare('SELECT * FROM eventos WHERE id = ?').get(id);
    if (!e) return null;
    return { ...e, disponibles: e.capacidad - ocupados(e.id) };
  },
  crear({ nombre, descripcion, fecha, lugar, capacidad, precio }) {
    const info = db.prepare(
      'INSERT INTO eventos (nombre, descripcion, fecha, lugar, capacidad, precio) VALUES (?,?,?,?,?,?)'
    ).run(nombre, descripcion || null, fecha, lugar, capacidad, precio);
    return this.porId(info.lastInsertRowid);
  },
  actualizar(id, campos) {
    const actual = db.prepare('SELECT * FROM eventos WHERE id = ?').get(id);
    if (!actual) return null;
    const m = { ...actual, ...campos };
    db.prepare(
      'UPDATE eventos SET nombre=?, descripcion=?, fecha=?, lugar=?, capacidad=?, precio=? WHERE id=?'
    ).run(m.nombre, m.descripcion, m.fecha, m.lugar, m.capacidad, m.precio, id);
    return this.porId(id);
  },
  eliminar(id) {
    return db.prepare('DELETE FROM eventos WHERE id = ?').run(id).changes > 0;
  },
};

module.exports = Evento;
