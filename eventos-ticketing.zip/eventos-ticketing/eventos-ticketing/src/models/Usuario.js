const db = require('../config/database');

const Usuario = {
  crear({ nombre, email, password_hash, rol = 'cliente' }) {
    const info = db.prepare(
      'INSERT INTO usuarios (nombre, email, password_hash, rol) VALUES (?, ?, ?, ?)'
    ).run(nombre, email, password_hash, rol);
    return this.porId(info.lastInsertRowid);
  },
  porEmail(email) {
    return db.prepare('SELECT * FROM usuarios WHERE email = ?').get(email);
  },
  porId(id) {
    return db.prepare('SELECT id, nombre, email, rol, createdAt FROM usuarios WHERE id = ?').get(id);
  },
};

module.exports = Usuario;
