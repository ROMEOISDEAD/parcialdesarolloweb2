const db = require('../config/database');

const Ticket = {
  crear({ codigo_unico, estado, reserva_expira, usuario_id, evento_id }) {
    const info = db.prepare(
      'INSERT INTO tickets (codigo_unico, estado, reserva_expira, usuario_id, evento_id) VALUES (?,?,?,?,?)'
    ).run(codigo_unico, estado, reserva_expira ?? null, usuario_id, evento_id);
    return this.porId(info.lastInsertRowid);
  },
  porId(id) {
    return db.prepare('SELECT * FROM tickets WHERE id = ?').get(id);
  },
  porIdYUsuario(id, usuario_id) {
    return db.prepare('SELECT * FROM tickets WHERE id = ? AND usuario_id = ?').get(id, usuario_id);
  },
  actualizarEstado(id, estado, reserva_expira = null) {
    db.prepare('UPDATE tickets SET estado = ?, reserva_expira = ? WHERE id = ?').run(estado, reserva_expira, id);
    return this.porId(id);
  },
  // JOIN tickets <-> eventos para el usuario
  porUsuario(usuario_id) {
    return db.prepare(
      `SELECT t.*, e.nombre AS evento_nombre, e.fecha AS evento_fecha,
              e.lugar AS evento_lugar, e.precio AS evento_precio
       FROM tickets t JOIN eventos e ON e.id = t.evento_id
       WHERE t.usuario_id = ? ORDER BY t.createdAt DESC`
    ).all(usuario_id).map(formatear);
  },
  // JOIN tickets <-> eventos <-> usuarios (admin)
  listarTodos() {
    return db.prepare(
      `SELECT t.*, e.nombre AS evento_nombre, u.nombre AS usuario_nombre, u.email AS usuario_email
       FROM tickets t
       JOIN eventos e ON e.id = t.evento_id
       JOIN usuarios u ON u.id = t.usuario_id
       ORDER BY t.createdAt DESC`
    ).all().map((r) => ({
      ...r,
      Evento: { nombre: r.evento_nombre },
      Usuario: { nombre: r.usuario_nombre, email: r.usuario_email },
    }));
  },
};

function formatear(r) {
  return {
    ...r,
    Evento: { nombre: r.evento_nombre, fecha: r.evento_fecha, lugar: r.evento_lugar, precio: r.evento_precio },
  };
}

module.exports = Ticket;
