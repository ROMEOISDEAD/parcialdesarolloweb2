const { validationResult } = require('express-validator');
const Evento = require('../models/Evento');

exports.listar = (req, res) => {
  try { res.json(Evento.listar()); }
  catch (err) { res.status(500).json({ error: 'Error al listar eventos' }); }
};

exports.obtener = (req, res) => {
  try {
    const e = Evento.porId(req.params.id);
    if (!e) return res.status(404).json({ error: 'Evento no encontrado' });
    res.json(e);
  } catch (err) { res.status(500).json({ error: 'Error al obtener evento' }); }
};

exports.crear = (req, res) => {
  const errores = validationResult(req);
  if (!errores.isEmpty()) return res.status(400).json({ errores: errores.array() });
  try { res.status(201).json(Evento.crear(req.body)); }
  catch (err) { res.status(500).json({ error: 'Error al crear evento' }); }
};

exports.actualizar = (req, res) => {
  try {
    const e = Evento.actualizar(req.params.id, req.body);
    if (!e) return res.status(404).json({ error: 'Evento no encontrado' });
    res.json(e);
  } catch (err) { res.status(500).json({ error: 'Error al actualizar evento' }); }
};

exports.eliminar = (req, res) => {
  try {
    const ok = Evento.eliminar(req.params.id);
    if (!ok) return res.status(404).json({ error: 'Evento no encontrado' });
    res.json({ mensaje: 'Evento eliminado' });
  } catch (err) { res.status(500).json({ error: 'Error al eliminar evento' }); }
};
