const { randomUUID } = require('crypto');
const Ticket = require('../models/Ticket');
const Evento = require('../models/Evento');

const MINUTOS_RESERVA = 10;

// POST /api/tickets/reservar -> reserva temporal
exports.reservar = (req, res) => {
  try {
    const { evento_id } = req.body;
    const evento = Evento.porId(evento_id);
    if (!evento) return res.status(404).json({ error: 'Evento no encontrado' });
    if (Evento.ocupados(evento_id) >= evento.capacidad) return res.status(409).json({ error: 'Evento agotado' });

    const ticket = Ticket.crear({
      codigo_unico: randomUUID(),
      estado: 'reservado',
      reserva_expira: Date.now() + MINUTOS_RESERVA * 60 * 1000,
      usuario_id: req.usuario.id,
      evento_id,
    });
    res.status(201).json({ mensaje: `Ticket reservado por ${MINUTOS_RESERVA} minutos`, ticket });
  } catch (err) { res.status(500).json({ error: 'Error al reservar ticket' }); }
};

// POST /api/tickets/comprar -> confirma reserva o compra directa
exports.comprar = (req, res) => {
  try {
    const { ticket_id, evento_id } = req.body;
    let ticket;

    if (ticket_id) {
      ticket = Ticket.porIdYUsuario(ticket_id, req.usuario.id);
      if (!ticket) return res.status(404).json({ error: 'Reserva no encontrada' });
      if (ticket.estado === 'pagado') return res.status(409).json({ error: 'El ticket ya esta pagado' });
      if (ticket.estado === 'reservado' && ticket.reserva_expira && ticket.reserva_expira < Date.now()) {
        Ticket.actualizarEstado(ticket.id, 'expirado');
        return res.status(410).json({ error: 'La reserva expiro' });
      }
    } else {
      const evento = Evento.porId(evento_id);
      if (!evento) return res.status(404).json({ error: 'Evento no encontrado' });
      if (Evento.ocupados(evento_id) >= evento.capacidad) return res.status(409).json({ error: 'Evento agotado' });
      ticket = Ticket.crear({
        codigo_unico: randomUUID(), estado: 'reservado',
        usuario_id: req.usuario.id, evento_id,
      });
    }

    const pagado = Ticket.actualizarEstado(ticket.id, 'pagado', null);
    res.json({ mensaje: 'Compra confirmada', ticket: pagado });
  } catch (err) { res.status(500).json({ error: 'Error al confirmar compra' }); }
};

exports.misTickets = (req, res) => {
  try { res.json(Ticket.porUsuario(req.usuario.id)); }
  catch (err) { res.status(500).json({ error: 'Error al obtener tickets' }); }
};

exports.listarTodos = (req, res) => {
  try { res.json(Ticket.listarTodos()); }
  catch (err) { res.status(500).json({ error: 'Error al listar tickets' }); }
};
