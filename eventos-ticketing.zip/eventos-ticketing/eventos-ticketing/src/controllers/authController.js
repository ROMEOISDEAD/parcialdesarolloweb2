const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator');
const Usuario = require('../models/Usuario');

function firmarToken(u) {
  return jwt.sign(
    { id: u.id, rol: u.rol, email: u.email },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES || '2h' }
  );
}

exports.register = async (req, res) => {
  const errores = validationResult(req);
  if (!errores.isEmpty()) return res.status(400).json({ errores: errores.array() });
  try {
    const { nombre, email, password, rol } = req.body;
    if (Usuario.porEmail(email)) return res.status(409).json({ error: 'El email ya esta registrado' });
    const password_hash = await bcrypt.hash(password, 10);
    const usuario = Usuario.crear({ nombre, email, password_hash, rol: rol === 'admin' ? 'admin' : 'cliente' });
    const token = firmarToken(usuario);
    res.status(201).json({ mensaje: 'Usuario registrado', token, usuario });
  } catch (err) {
    res.status(500).json({ error: 'Error al registrar usuario' });
  }
};

exports.login = async (req, res) => {
  const errores = validationResult(req);
  if (!errores.isEmpty()) return res.status(400).json({ errores: errores.array() });
  try {
    const { email, password } = req.body;
    const usuario = Usuario.porEmail(email);
    if (!usuario) return res.status(401).json({ error: 'Credenciales invalidas' });
    const valido = await bcrypt.compare(password, usuario.password_hash);
    if (!valido) return res.status(401).json({ error: 'Credenciales invalidas' });
    const token = firmarToken(usuario);
    res.json({
      mensaje: 'Login exitoso',
      token,
      usuario: { id: usuario.id, nombre: usuario.nombre, email: usuario.email, rol: usuario.rol },
    });
  } catch (err) {
    res.status(500).json({ error: 'Error al iniciar sesion' });
  }
};
