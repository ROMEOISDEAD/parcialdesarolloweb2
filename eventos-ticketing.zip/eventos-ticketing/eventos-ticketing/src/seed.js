require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./config/database');
const Usuario = require('./models/Usuario');
const Evento = require('./models/Evento');

async function seed() {
  // Limpia tablas
  db.exec('DELETE FROM tickets; DELETE FROM eventos; DELETE FROM usuarios;');

  Usuario.crear({ nombre: 'Administrador', email: 'admin@eventos.com', password_hash: await bcrypt.hash('admin123', 10), rol: 'admin' });
  Usuario.crear({ nombre: 'Cliente Demo', email: 'cliente@eventos.com', password_hash: await bcrypt.hash('cliente123', 10), rol: 'cliente' });

  Evento.crear({ nombre: 'Concierto Junior FC - Celebracion', descripcion: 'Evento musical en el estadio', fecha: '2026-08-15T20:00:00', lugar: 'Estadio Metropolitano, Barranquilla', capacidad: 100, precio: 50000 });
  Evento.crear({ nombre: 'Conferencia Tech Caribe 2026', descripcion: 'Charlas de desarrollo web y cloud', fecha: '2026-09-10T09:00:00', lugar: 'Centro de Eventos Puerta de Oro', capacidad: 50, precio: 30000 });
  Evento.crear({ nombre: 'Festival Gastronomico', descripcion: 'Comida tipica de la costa', fecha: '2026-07-20T12:00:00', lugar: 'Parque Sagrado Corazon', capacidad: 200, precio: 15000 });

  console.log('  Datos de prueba creados');
  console.log('  Admin:   admin@eventos.com / admin123');
  console.log('  Cliente: cliente@eventos.com / cliente123');
}

seed().catch((e) => { console.error(e); process.exit(1); });
